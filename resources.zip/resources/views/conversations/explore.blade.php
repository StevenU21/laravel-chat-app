@extends('layouts.panel')
@section('title', 'Explorar')

@section('content')
    @livewire('chat.create-chat')
@endsection
