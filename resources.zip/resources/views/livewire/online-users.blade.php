<div class="col-8">
    <div class="numbers">
        <p class="text-sm mb-0 text-uppercase font-weight-bold">Usuarios Activos:</p>
        <h5 class="font-weight-bolder">
            {{ $onlineUsers }}
        </h5>
    </div>
</div>
